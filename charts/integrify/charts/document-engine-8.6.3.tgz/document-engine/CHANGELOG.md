# Changelog

- [Changelog](#changelog)
  - [8.6.3 (2026-09-02)](#863-2026-09-02)
  - [8.6.2 (2026-09-01)](#862-2026-09-01)
  - [8.6.1 (2026-08-25)](#861-2026-08-25)
  - [8.6.0 (2026-08-20)](#860-2026-08-20)
  - [8.5.0 (2026-06-29)](#850-2026-06-29)
  - [8.4.0 (2026-05-28)](#840-2026-05-28)
    - [Added](#added)
    - [Changed](#changed)
  - [8.3.1 (2026-05-08)](#831-2026-05-08)
    - [Changed](#changed-1)
  - [8.3.0 (2026-05-06)](#830-2026-05-06)
    - [Added](#added-1)
  - [8.2.3 (2026-05-04)](#823-2026-05-04)
    - [Added](#added-2)
  - [8.2.2 (2026-04-20)](#822-2026-04-20)
    - [Changed](#changed-2)
  - [8.2.1 (2026-04-09)](#821-2026-04-09)
    - [Changed](#changed-3)
  - [8.2.0 (2026-03-26)](#820-2026-03-26)
    - [Changed](#changed-4)
  - [8.1.2 (2026-03-24)](#812-2026-03-24)
    - [Changed](#changed-5)
  - [8.1.1 (2026-03-12)](#811-2026-03-12)
    - [Fixed](#fixed)
  - [8.1.0 (2026-02-28)](#810-2026-02-28)
    - [Added](#added-3)
    - [Changed](#changed-6)
  - [8.0.7 (2026-02-27)](#807-2026-02-27)
    - [Fixed](#fixed-1)
  - [8.0.6 (2026-02-26)](#806-2026-02-26)
    - [Changed](#changed-7)
  - [8.0.5 (2026-02-26)](#805-2026-02-26)
    - [Fixed](#fixed-2)
    - [Changed](#changed-8)
  - [8.0.4 (2026-02-26)](#804-2026-02-26)
    - [Fixed](#fixed-3)
  - [8.0.3 (2026-02-26)](#803-2026-02-26)
    - [Fixed](#fixed-4)
  - [8.0.0 (2026-02-26)](#800-2026-02-26)
    - [Added](#added-4)
    - [Changed](#changed-9)
  - [7.6.1 (2026-02-24)](#761-2026-02-24)
    - [Fixed](#fixed-5)
  - [7.6.0 (2026-02-03)](#760-2026-02-03)
    - [Changed](#changed-10)
  - [7.5.1 (2026-02-01)](#751-2026-02-01)
    - [Added](#added-5)
    - [Changed](#changed-11)
  - [7.5.0 (2026-01-09)](#750-2026-01-09)
    - [Added](#added-6)
  - [7.4.0 (2025-12-15)](#740-2025-12-15)
    - [Changed](#changed-12)
    - [Fixed](#fixed-6)
  - [7.3.0 (2025-11-21)](#730-2025-11-21)
    - [Changed](#changed-13)
  - [7.2.1 (2025-11-01)](#721-2025-11-01)
    - [Changed](#changed-14)
  - [7.2.0 (2025-11-01)](#720-2025-11-01)
    - [Added](#added-7)
  - [7.1.4 (2025-10-27)](#714-2025-10-27)
    - [Changed](#changed-15)
  - [7.1.3 (2025-10-23)](#713-2025-10-23)
    - [Changed](#changed-16)
  - [7.1.2 (2025-10-22)](#712-2025-10-22)
    - [Fixed](#fixed-7)
  - [7.1.1 (2025-10-22)](#711-2025-10-22)
    - [Fixed](#fixed-8)
  - [7.1.0 (2025-10-22)](#710-2025-10-22)
    - [Changed](#changed-17)
  - [7.0.1 (2025-10-13)](#701-2025-10-13)
    - [Changed](#changed-18)
  - [7.0.0 (2025-10-09)](#700-2025-10-09)
    - [Added](#added-8)
    - [Changed](#changed-19)
  - [6.3.1 (2025-10-08)](#631-2025-10-08)
    - [Changed](#changed-20)
  - [6.3.0 (2025-10-07)](#630-2025-10-07)
    - [Changed](#changed-21)
  - [6.2.0 (2025-10-07)](#620-2025-10-07)
    - [Added](#added-9)
  - [6.1.0 (2025-10-05)](#610-2025-10-05)
    - [Changed](#changed-22)
  - [6.0.0 (2025-10-01)](#600-2025-10-01)
    - [Added](#added-10)
    - [Changed](#changed-23)
  - [5.4.1 (2025-09-28)](#541-2025-09-28)
    - [Added](#added-11)
  - [5.4.0 (2025-09-23)](#540-2025-09-23)
    - [Changed](#changed-24)
    - [Fixed](#fixed-9)
  - [5.3.0 (2025-09-21)](#530-2025-09-21)
    - [Added](#added-12)
  - [5.2.0 (2025-08-25)](#520-2025-08-25)
    - [Changed](#changed-25)
  - [5.1.3 (2025-07-24)](#513-2025-07-24)
    - [Changed](#changed-26)
  - [5.1.2 (2025-07-16)](#512-2025-07-16)
    - [Added](#added-13)
  - [5.1.1 (2025-07-08)](#511-2025-07-08)
    - [Changed](#changed-27)
  - [5.1.0 (2025-07-05)](#510-2025-07-05)
    - [Changed](#changed-28)
  - [5.0.1 (2025-06-27)](#501-2025-06-27)
    - [Fixed](#fixed-10)
  - [5.0.0 (2025-06-27)](#500-2025-06-27)
    - [Added](#added-14)
    - [Changed](#changed-29)
  - [4.0.1 (2025-06-24)](#401-2025-06-24)
    - [Fixed](#fixed-11)
  - [4.0.0 (2025-06-24)](#400-2025-06-24)
    - [Added](#added-15)
    - [Changed](#changed-30)
  - [3.10.1 (2025-06-18)](#3101-2025-06-18)
    - [Changed](#changed-31)
  - [3.10.0 (2025-06-10)](#3100-2025-06-10)
    - [Added](#added-16)
  - [3.9.1 (2025-06-09)](#391-2025-06-09)
    - [Changed](#changed-32)
  - [3.9.0 (2025-05-29)](#390-2025-05-29)
    - [Changed](#changed-33)
  - [3.8.11 (2025-05-28)](#3811-2025-05-28)
    - [Changed](#changed-34)
  - [3.8.10 (2025-05-20)](#3810-2025-05-20)
    - [Changed](#changed-35)
  - [3.8.9 (2025-05-12)](#389-2025-05-12)
    - [Fixed](#fixed-12)
  - [3.8.8 (2025-05-12)](#388-2025-05-12)
    - [Changed](#changed-36)
  - [3.8.7 (2025-05-12)](#387-2025-05-12)
    - [Added](#added-17)
  - [3.8.6 (2025-04-09)](#386-2025-04-09)
    - [Changed](#changed-37)
  - [3.8.5 (2025-04-03)](#385-2025-04-03)
    - [Fixed](#fixed-13)
  - [3.8.4 (2025-04-03)](#384-2025-04-03)
    - [Fixed](#fixed-14)
  - [3.8.3 (2025-04-03)](#383-2025-04-03)
    - [Fixed](#fixed-15)
  - [3.8.2 (2025-04-03)](#382-2025-04-03)
    - [Fixed](#fixed-16)
  - [3.8.1 (2025-04-03)](#381-2025-04-03)
    - [Fixed](#fixed-17)
    - [Changed](#changed-38)
  - [3.8.0 (2025-04-03)](#380-2025-04-03)
    - [Added](#added-18)
  - [3.7.1 (2025-03-26)](#371-2025-03-26)
    - [Changed](#changed-39)
  - [3.7.0 (2025-03-20)](#370-2025-03-20)
    - [Changed](#changed-40)
  - [3.6.0 (2025-03-19)](#360-2025-03-19)
    - [Changed](#changed-41)
  - [3.5.0 (2025-02-14)](#350-2025-02-14)
    - [Changed](#changed-42)
  - [3.4.0 (2025-02-11)](#340-2025-02-11)
    - [Changed](#changed-43)
  - [3.3.4 (2025-01-28)](#334-2025-01-28)
    - [Changed](#changed-44)
  - [3.3.3 (2024-01-15)](#333-2024-01-15)
    - [Changed](#changed-45)
  - [3.3.2 (2025-01-15)](#332-2025-01-15)
    - [Changed](#changed-46)
  - [3.3.1 (2025-01-10)](#331-2025-01-10)
    - [Added](#added-19)
  - [3.2.12 (2024-12-05)](#3212-2024-12-05)
    - [Changed](#changed-47)
  - [3.2.11 (2024-11-21)](#3211-2024-11-21)
    - [Changed](#changed-48)
  - [3.2.10 (2024-11-18)](#3210-2024-11-18)
    - [Changed](#changed-49)
  - [3.2.9 (2024-11-15)](#329-2024-11-15)
    - [Changed](#changed-50)
  - [3.2.7 (2024-11-15)](#327-2024-11-15)
    - [Added](#added-20)
    - [Changed](#changed-51)
  - [3.2.6 (2024-10-29)](#326-2024-10-29)
    - [Added](#added-21)
    - [Changed](#changed-52)
  - [3.2.5 (2024-10-24)](#325-2024-10-24)
    - [Changed](#changed-53)
  - [3.2.4 (2024-10-17)](#324-2024-10-17)
    - [Fixed](#fixed-18)
  - [3.2.3 (2024-10-16)](#323-2024-10-16)
    - [Fixed](#fixed-19)
  - [3.2.2 (2024-10-09)](#322-2024-10-09)
    - [Changed](#changed-54)
  - [3.2.1 (2024-09-20)](#321-2024-09-20)
    - [Changed](#changed-55)
  - [3.2.0 (2024-08-29)](#320-2024-08-29)
    - [Changed](#changed-56)
  - [3.1.2 (2024-08-23)](#312-2024-08-23)
    - [Changed](#changed-57)
  - [3.1.1 (2024-08-23)](#311-2024-08-23)
    - [Fixed](#fixed-20)
  - [3.1.0 (2024-08-22)](#310-2024-08-22)
    - [Added](#added-22)
  - [3.0.6 (2024-08-22)](#306-2024-08-22)
    - [Changed](#changed-58)
  - [3.0.5 (2024-08-21)](#305-2024-08-21)
    - [Fixed](#fixed-21)
  - [3.0.4 (2024-08-21)](#304-2024-08-21)
    - [Changed](#changed-59)
    - [Added](#added-23)
  - [2.9.3 (2024-08-16)](#293-2024-08-16)
    - [Fixed](#fixed-22)
  - [2.9.2 (2024-08-13)](#292-2024-08-13)
    - [Changed](#changed-60)
  - [2.9.1 (2024-08-10)](#291-2024-08-10)
    - [Added](#added-24)
    - [Changed](#changed-61)
  - [2.9.0 (2024-08-01)](#290-2024-08-01)
    - [Added](#added-25)
    - [Changed](#changed-62)
    - [Fixed](#fixed-23)
  - [2.8.0](#280)
    - [Added](#added-26)
    - [Changed](#changed-63)
    - [Fixed](#fixed-24)
  - [2.7.3](#273)
    - [Changed](#changed-64)
    - [Fixed](#fixed-25)
  - [2.7.2](#272)
    - [Fixed](#fixed-26)
  - [2.7.0](#270)
    - [Changed](#changed-65)
  - [2.6.2](#262)
    - [Added](#added-27)
    - [Changed](#changed-66)
  - [2.6.0](#260)
    - [Added](#added-28)
  - [2.4.0](#240)
    - [Added](#added-29)
  - [2.3.0](#230)
    - [Added](#added-30)
  - [2.2.0](#220)
    - [Added](#added-31)
  - [2.1.0](#210)
    - [Changed](#changed-67)
  - [2.0.0](#200)
    - [Changed](#changed-68)

## 8.6.3 (2026-09-02)

* Removed the note in the `Clustering` section calling it experimental. Clustering is supported.
* `README.md.gotmpl`: removed section-wide note support, which had no remaining users.

## 8.6.2 (2026-09-01)

* Updated Document Engine to 1.18.1.

## 8.6.1 (2026-08-25)

* Corrected the description of `terminationGracePeriodSeconds`, which implied it governs how long in-flight requests are given to finish.

## 8.6.0 (2026-08-20)

* Updated Document Engine to 1.18.0.

## 8.5.0 (2026-06-29)

* Updated Document Engine to 1.17.0.
* Added Helm values for async job admission, worker queues, retry, retention, and encryption settings.
* Added external Secret support for `ASYNC_JOB_ENCRYPTION_KEYS`.
* Added Helm values for batch render, remote URL fetch policy, and full-text search settings.

## 8.4.0 (2026-05-28)

### Added

* Added `observability.log.structuredFlatten`, which renders the `LOG_STRUCTURED_FLATTEN` environment variable. Only applies when `observability.log.structured` is `true`. Defaults to `true`, matching the Document Engine 1.16.0 default.

### Changed

* Updated Document Engine to 1.16.0.
* `config.tileMaxScale` now defaults to unlimited (unset). Previously the chart pinned `TILE_MAX_SCALE=16`. Document Engine 1.16.0 enforces the limit on `GET`, `POST` and HTTP/2 tile rendering, so leaving it unset matches the upstream default. To preserve the previous behavior, set `config.tileMaxScale: 16` explicitly.

## 8.3.1 (2026-05-08)

### Changed

* Changed the default `config.tileMaxScale` value from `2` to `16`.

## 8.3.0 (2026-05-06)

### Added

* Added `config.tileMaxScale`, which renders the `TILE_MAX_SCALE` environment variable.

## 8.2.3 (2026-05-04)

### Added

* New clustering panels in the Document Engine Grafana dashboard

## 8.2.2 (2026-04-20)

### Changed

* MinIO references replaced with Garage

## 8.2.1 (2026-04-09)

### Changed

* [Document Engine 1.15.1](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.15.1)
* New options `workerPoolMaxRestarts` and `workerPoolMaxSeconds` are available to control the worker supervisor restart throttling.

## 8.2.0 (2026-03-26)

### Changed

* [Document Engine 1.15.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.15.0)
* New options `daemonReadTimeoutSeconds` and `daemonWriteTimeoutSeconds` are available to control the worker daemon socket timeouts

## 8.1.2 (2026-03-24)

### Changed

* `README.md.gotmpl`: added support for section-wide notes in generated values sections
* `README.md`: added a note in the `Clustering` section that it is an experimental feature

## 8.1.1 (2026-03-12)

### Fixed

* `ingress-extra.yaml`: fixed invalid YAML document separator (`---apiVersion:` merged onto one line) caused by aggressive whitespace trimming in the template
* `test-api-documents.yaml`: fixed wrong document ID in DELETE call (`test` instead of `test-document-id-13`)
* `httproute-extra.yaml`: added guard comment near `---` separator to prevent the same whitespace trimming bug
* Minor misprints in `values.yaml`

## 8.1.0 (2026-02-28)

### Added

* Gateway API support under `gateway.*` for creating [HTTPRoute](https://gateway-api.sigs.k8s.io/api-types/httproute/) resources as an alternative to Ingress
* Optional chart-managed [Gateway](https://gateway-api.sigs.k8s.io/api-types/gateway/) resource via `gateway.gateway.*`
* `gateway.extraHTTPRoutes` for additional HTTPRoute resources (analogous to `extraIngresses`)
* HTTPRoute `parentRefs` auto-wiring to the chart-managed Gateway when `gateway.gateway.enabled=true` and `gateway.parentRefs` is empty

### Changed

* Autoscaling: no dewfault CPU and memory target values, for more flexibility

## 8.0.7 (2026-02-27)

### Fixed

* Another path correction for stateful asset cache

## 8.0.6 (2026-02-26)

### Changed

* Better section semantics

## 8.0.5 (2026-02-26)

### Fixed

* PDB should be disabled by default

### Changed

* Default `null` values for PDBs

## 8.0.4 (2026-02-26)

### Fixed

* Schema for PDB

## 8.0.3 (2026-02-26)

### Fixed

* Persistence: made it work

## 8.0.0 (2026-02-26)

### Added

* Persistent local asset cache through `workloadType`. Defaults to `Deployment` (old behaviour), also accepts `StatefulSet` with persistent storage via `volumeClaimTemplates`
  * `podManagementPolicy` for StatefulSet pod management (`OrderedReady` or `Parallel`)
  * `persistence` configuration block (`storageClassName`, `accessModes`, `size`, `mountPath`, `annotations`) for StatefulSet persistent volumes
  * Note that the size of the volumes (`persistence.size`) must be larger than the local cache size limit (`assetStorage.localCacheSizeMegabytes`)

### Changed

* Headless service is now also created when `workloadType` is `StatefulSet`
* HPA dynamically targets `StatefulSet` or `Deployment` based on `workloadType`
* Extracted pod template into `_pod-template.tpl` shared by both workload types
* Reusable helpers for scheduling and certificate trust, reducing duplication in migration job

## 7.6.1 (2026-02-24)

### Fixed

* Corrected the PostgreSQL TLS common name mapping: `database.postgres.tls.commonName` now renders `PGSSL_CERT_COMMON_NAME`, no longer overwriting `PGSSL_CA_CERTS`.

## 7.6.0 (2026-02-03)

### Changed

* [Document Engine 1.14.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.14.0)

## 7.5.1 (2026-02-01)

### Added

* By [InosRahul](https://github.com/InosRahul): `documentLifecycle.expirationJob.deletionPrefix` to set document id prefix for the expiration jobs, defaults to `ephemeral`, leave empty to delete all documents older than `documentLifecycle.expirationJob.keepHours` hours

### Changed

* Removed disabled `documentLifecycle.expirationJob.persistentLike` value

## 7.5.0 (2026-01-09)

### Added

* `dashboard.rateLimitingEnabled` to enable rate limiting for dashboard authentication (prevents brute force attacks)
* `dashboard.rateLimitingMaxRequests` to configure maximum failed attempts before blocking (default: 5)
* `dashboard.rateLimitingWindowMs` to configure the time window for tracking attempts (default: 60000ms)

## 7.4.0 (2025-12-15)

### Changed

* Switched to Document Engine image for the expiration jobs, and consequently, removed `documentLifecycle.image`
* Document expiration job output

### Fixed 

* Document expiration job did not expire documents

## 7.3.0 (2025-11-21)

### Changed

* [Document Engine 1.13.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.13.0)

## 7.2.1 (2025-11-01)

### Changed

* Disabled Envoy in case there is only one replica

## 7.2.0 (2025-11-01)

### Added

* Added Envoy as an optional sidecar for better load distrubution using consistent hashing

## 7.1.4 (2025-10-27)

### Changed

* Added `data_checksums` by default to CloudNativePG Cluster spec

## 7.1.3 (2025-10-23)

### Changed

* Update Grafana dashboard

## 7.1.2 (2025-10-22)

### Fixed

* Fix timeline in Grafana dashboard

## 7.1.1 (2025-10-22)

### Fixed

* ([masterkain](https://github.com/masterkain)) Wrong Redis TTL units
* ([masterkain](https://github.com/masterkain)) inline S3 credentials (when `assetStorage.s3.externalSecretName` is not set)
* ([masterkain](https://github.com/masterkain)) inline Redis credentials (when `assetStorage.redis.externalSecretName` is not set)
* ([masterkain](https://github.com/masterkain)) Azure Blob Storage secret name

## 7.1.0 (2025-10-22)

### Changed

* Massive upgrade of the Grafana dashboard

## 7.0.1 (2025-10-13)

### Changed

* [Document Engine 1.12.2](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.12.2)

## 7.0.0 (2025-10-09)

### Added

* `documentLifecycle.bulkDocumentDeletionEnabled` to allow bulk document deletion endpoint (`/api/async/delete_documents`).

### Changed

* Expiration job (`documentLifecycle.expirationJob`) now requires `documentLifecycle.bulkDocumentDeletionEnabled` to be `true`.
* Changed the expiration job to use the new `/api/async/delete_documents` endpoint.

## 6.3.1 (2025-10-08)

### Changed

* [Document Engine 1.12.1](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.12.1)

## 6.3.0 (2025-10-07)

### Changed

* [Document Engine 1.12.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.12.0)

## 6.2.0 (2025-10-07)

### Added

* `cloudNativePG.clusterName` to set the name of CloudNativePG cluster.

## 6.1.0 (2025-10-05)

### Changed

* `database.postgres.host` defaults to be empty now, to rely on the CloudNativePG cluster.

## 6.0.0 (2025-10-01)

### Added

* `cloudNativePG` section, including `cloudNativePG.cluster` to create PostgreSQL database clusters using [CloudNativePG](https://cloudnative-pg.io/) operator.
* `observability.log.structured` to enable structured logs in JSON format.
* Added `config.hoard` map to cover internal caching engine parameters.

### Changed

* Removed `postgresql`, `minio` and `redis` Bitnami chart dependencies, and the corresponding sections in the values file.
* Renamed `documentLifecycle.cleanupJob` to `documentLifecycle.expirationJob` for better understanding.
* Restructured files.

## 5.4.1 (2025-09-28)

### Added

* `service.trafficDistribution` to allow setting traffic routing properties.

## 5.4.0 (2025-09-23)

### Changed

* No longer support multiple namespaces for Grafana dashboard (removed `observability.metrics.grafanaDashboard.allNamespaces`).

### Fixed

* Grafana dashboard metric names.

## 5.3.0 (2025-09-21)

### Added

* Service annotations and internal traffic policy.

## 5.2.0 (2025-08-25)

### Changed

* [Document Engine 1.11.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.11.0)

## 5.1.3 (2025-07-24)

### Changed

* [Document Engine 1.10.1](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.10.1)

## 5.1.2 (2025-07-16)

### Added

* `assetStorage.localCacheTimeoutSeconds` to set asset storage cache fetch timeout.

## 5.1.1 (2025-07-08)

### Changed

* Better default timeouts for HTTP/2 based shared rendering.

## 5.1.0 (2025-07-05)

### Changed

* Better dependency hostname handling (default templated hostnames).

## 5.0.1 (2025-06-27)

### Fixed

* Misprint in the Grafana dashboard resource.

## 5.0.0 (2025-06-27)

### Added

* `observability.metrics.prometheusEndpoint` to allow enabling Prometheus endpoint for scraping metrics.
* `observability.metrics.customTags` to set custom tags for all exporters.

### Changed

* [Document Engine 1.10.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.10.0).
* Removed `prometheusExporter`, due to the new native support of Prometheus metrics.
* Removed redundant `observability.metrics.enabled`.

## 4.0.1 (2025-06-24)

### Fixed

* A very stupid mistake with dates in the cleanup jobs.
* Removed unnecessary port exposure.

## 4.0.0 (2025-06-24)

### Added

* New cleanup job way through the dedicated API instead of the direct database query workaround. Important limitation: document id filtering does not currently work, only the retention time (`documentLifecycle.cleanupJob.keepHours`).

### Changed

* Improved the tests.
* Updated dependency charts.

## 3.10.1 (2025-06-18)

### Changed

* Minor improvements.

## 3.10.0 (2025-06-10)

### Added

* `config.http2SharedRendering.enabled` (`false` by default) to allow new (better) shared rendering using HTTP/2, which requires load balancer to support that.

## 3.9.1 (2025-06-09)

### Changed

* `README.md` update.
* Polished the schema.

## 3.9.0 (2025-05-29)

### Changed

* [Document Engine 1.9.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.9.0).


## 3.8.11 (2025-05-28)

### Changed

* Better timeout defaults.
* Documented timeout relations.

## 3.8.10 (2025-05-20)

### Changed

* Better defaults for horisontal pod autoscaling.
* Updated dependencies.

## 3.8.9 (2025-05-12)

### Fixed

* Grafana dashboard improvement fix.

## 3.8.8 (2025-05-12)

### Changed

* Grafana dashboard improvement.

## 3.8.7 (2025-05-12)

### Added

* Additional selectors for the pod template in Deployment: `deploymentExtraSelectorLabels`. Can be used to separate pods for debugging and testing purposes.

## 3.8.6 (2025-04-09)

### Changed

* [Document Engine 1.8.3](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.8.3)

## 3.8.5 (2025-04-03)

### Fixed

* Final touch on dashboard uniqueness.

## 3.8.4 (2025-04-03)

### Fixed

* Found the cause of dashboard discoverability problem.

## 3.8.3 (2025-04-03)

### Fixed

* More dashboard discoverability problems.

## 3.8.2 (2025-04-03)

### Fixed

* Another dashboard hiccup.

## 3.8.1 (2025-04-03)

### Fixed

* More unique Grafana dashboard UID.

### Changed

* Added Grafana dashboard tags

## 3.8.0 (2025-04-03)

### Added

* Grafana dashboard through a ConfigMap. Use:
  * `observability.metrics.grafanaDashboard.enabled` to enable — also requires Prometheus exporter and StatsD output
  * `observability.metrics.grafanaDashboard.title` — to change the dashboard title
  * `observability.metrics.grafanaDashboard.allNamespaces` — to cover all namespaces instead of the release one

## 3.7.1 (2025-03-26)

### Changed

* [Document Engine 1.8.2](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.8.2)

## 3.7.0 (2025-03-20)

### Changed

* [Document Engine 1.8.1](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.8.1)

## 3.6.0 (2025-03-19)

### Changed

* [Document Engine 1.8.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.8.0)

## 3.5.0 (2025-02-14)

### Changed

* [Document Engine 1.7.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.7.0)

## 3.4.0 (2025-02-11)

### Changed

* [Document Engine 1.6.0](https://www.nutrient.io/guides/document-engine/release-notes/changelog/#1.6.0)

## 3.3.4 (2025-01-28)

### Changed

* [Document Engine 1.5.6](https://www.nutrient.io/changelog/document-engine/#1.5.6)

## 3.3.3 (2024-01-15)

### Changed

* Updated Network Policy to allow inter-node communication.

## 3.3.2 (2025-01-15)

### Changed

* Updated statsd_exporter and dependency chart versions.

## 3.3.1 (2025-01-10)

### Added

* Support for creating Erlang cluster using Kubernetes DNS.

## 3.2.12 (2024-12-05)

### Changed

* [Document Engine 1.5.5](https://www.nutrient.io/changelog/document-engine/#1.5.5)

## 3.2.11 (2024-11-21)

### Changed

* [Document Engine 1.5.4](https://www.nutrient.io/changelog/document-engine/#1.5.4)

## 3.2.10 (2024-11-18)

### Changed

* Removed earlier added default `lifecycle`: dumb-init makes it unnecessary.

## 3.2.9 (2024-11-15)

### Changed

* More labels (e.g. `helm.sh/chart`) added to pods.

## 3.2.7 (2024-11-15)

### Added

* Revision history limit setting for Document Engine Deployment: `revisionHistoryLimit`.

### Changed

* Added a meaningful default for `lifecycle.preStop` to make Document Engine properly receive `SIGTERM`.

## 3.2.6 (2024-10-29)

### Added

* Support for file upload timeout for asset storage by setting `assetStorage.fileUploadTimeoutSeconds`.
* Spreadhseet content size limitations as `documentConversion.spreadsheetMaxContentHeightMm` and `documentConversion.spreadsheetMaxContentWidthMm`.

### Changed

* [Document Engine 1.5.3](https://www.nutrient.io/changelog/document-engine/#1.5.3)

## 3.2.5 (2024-10-24)

### Changed

* Documentation changes following the company rebrand: we are now Nutrient.

## 3.2.4 (2024-10-17)

### Fixed

* `podAnnotations` use in `storage-migration-job.yaml`

## 3.2.3 (2024-10-16)

### Fixed

* Simple values corrections.

## 3.2.2 (2024-10-09)

### Changed

* [Document Engine 1.5.2](https://www.nutrient.io/changelog/document-engine/#1.5.2)

## 3.2.1 (2024-09-20)

### Changed

* [Document Engine 1.5.1](https://www.nutrient.io/changelog/document-engine/#1.5.1)

## 3.2.0 (2024-08-29)

### Changed

* [Document Engine 1.5.0](https://www.nutrient.io/changelog/document-engine/#1.5.0)

## 3.1.2 (2024-08-23)

### Changed

* Polishing schema based on the available usage scenarios.
* Dependency charts versions update.
* Documentation layout change.

## 3.1.1 (2024-08-23)

### Fixed

* Wrong value type for `terminationGracePeriodSeconds`

## 3.1.0 (2024-08-22)

### Added

* Schema using [helm values schema json plugin](https://github.com/losisin/helm-values-schema-json)

## 3.0.6 (2024-08-22)

### Changed

* Documentation cleanup

## 3.0.5 (2024-08-21)

### Fixed

* Commit mistake correction

## 3.0.4 (2024-08-21)

> [!WARNING]
> Breaking changes.
> We hope that `values.yaml` will now be much more readable and usable.

### Changed

* Massive internal refactoring.
* Documentation generation.
* `pspdfkit.license.isOffline` is removed, as it is no longer necessary
* `pspdfkit.license` section moved to the top level as `documentEngineLicense`.
* `pspdfkit.auth.api` section moved to the top level as `apiAuth`, both `pspdfkit.auth.api.apiToken` and `pspdfkit.auth.api.jwt` section.
* `pspdfkit.secretKeyBase` restructured:
  * `pspdfkit.secretKeyBase.value` moved to `apiAuth.secretKeyBase`
  * Former optional `pspdfkit.secretKeyBase.externalSecret` integrated into `apiAuth.externalSecret`:
    * In case `apiAuth.externalSecret.secretKeyBaseKey` is set, the value is used.
* `pspdfkit.storage.cleanupJob` becomes `documentLifecycle.cleanupJob`
* Database-related part of `pspdfkit.storage` moved to `database`:
  * `pspdfkit.storage.postgres.enabled` becomes `database.enabled`
  * The rest of `pspdfkit.storage.postgres` becomes `database.postgres`
  * `pspdfkit.storage.databaseEngine` becomes `database.engine`, only `postgres` is currently supported (formerly `postgresql`)
  * `pspdfkit.storage.databaseConnections` becomes `database.connections`
  * `pspdfkit.storage.databaseMigrationJob` becomes `database.migrationJob`
* The remaining `pspdfkit.storage` section moved to the top level as `assetStorage`.
  * `pspdfkit.assetStorageCacheSizeMegaBytes` renamed to `assetStorage.localCacheSizeMegabytes`.
  * `pspdfkit.storage.assetStorageBackend` renamed to `assetStorage.backendType`
  * `pspdfkit.storage.enableAssetStorageFallback*` moved to `assetStorage.backendFallback` section
  * `pspdfkit.storage.redis.useTtlForPrerendering` renamed to `assetStorage.redis.useTtl`
* `pspdfkit.signingService` section moved to the top level as `documentSigningService`.
  * `pspdfkit.signingService.digitalSignatureHashAlgorithm` renamed to `documentSigningService.hashAlgorithm`
  * `pspdfkit.signingService.digitalSignatureCadesLevel` renamed to `documentSigningService.cadesLevel`
  * `pspdfkit.signingService.digitalSignatureCertificateCheckTime` renamed to `documentSigningService.certificateCheckTime`
* Certificate trust configuration restructured into the new `certificateTrust` section:
  * Map `pspdfkit.signingTrustConfigMaps` becomes list `certificateTrust.digitalSignatures` allowing both ConfigMaps and Secrets
  * Map `pspdfkit.trustConfigMaps` becomes list `certificateTrust.customCertificates` allowing both ConfigMaps and Secrets
  * `pspdfkit.downloaderTrustFileName` moved to `certificateTrust.downloaderTrustFileName` and is now empty by default which will set HTTP client trust to Mozilla CA bundle
  * `assetStorage.postgres.tls.trustFileName` will assume a file name from `/certificate-stores-custom`, which is filled from `certificateTrust.customCertificates`
* `pspdfkit.observability` section moved to the top level as `observability`.
  * `pspdfkit.log.level` moved into `observability.log.level`.
  * `metrics` section moved to `observability.metrics`.
* `pspdfkit.auth.dashboard` section became `dashboard`:
  * `pspdfkit.auth.dashboard.enabled` renamed to `dashboard.enabled`
  * The rest of the former section to `pspdfkit.dashboard.auth`
* The remaining `pspdfkit` section renamed to `config`.
* Aligned default values with the default [Document Engine configuration values](https://www.nutrient.io/guides/document-engine/configuration/options/), affects the following default values:
  * `config.workerPoolSize` changed from `8` to `16`
  * `config.maxUploadSizeMegaBytes` changed from `128` to `950`
  * `config.urlFetchTimeoutSeconds` changed from `20` to `5`
  * `config.generationTimeoutSeconds` changed from `120` to `20`
  * `config.requestTimeoutSeconds` changed from `120` to `60`
  * `config.automaticLinkExtraction` changed from `true` to `false`
* Exceptions to the previous list:
  * `config.trustedProxies` is left as `default` for safety reasons

### Added

* Health check log level as `observability.healthcheckLevel`.
* Direct trust bundle for PostgreSQL as `assetStorage.postgres.trustBundle`.
* Option for host verification of PostgreSQL, `assetStorage.postgres.hostVerify`.
* Worker timeout in seconds as `config.workerTimeoutSeconds`.
* Asynchronous jobs timeout in seconds as `config.asyncJobsTtlSeconds`.
* HTTP proxy settings: `config.proxy.http` for HTTP and `config.proxy.https` for HTTPS
* Explicit StatsD exporting parameters in `observability.metrics.statsd` section.
* One more chart test.

## 2.9.3 (2024-08-16)

### Fixed

* Signing trust certificates configuration.

## 2.9.2 (2024-08-13)

### Changed

* Additional test to cover migration from Docker Compose by being friendly to putting _all_ into `envFrom`.

## 2.9.1 (2024-08-10)

### Added

* Support for secrets rotation enablement option. Setting `pspdfkit.replaceSecretsFromEnv` to `false` will make Document Engine to ignore `JWT_PUBLIC_KEY`, `SECRET_KEY_BASE` and `DASHBOARD_PASSWORD` environment variables, values (`pspdfkit.auth.api.jwt.publicKey`, `pspdfkit.secretKeyBase` and `pspdfkit.auth.dashboard.password`) and the corresponding secrets.

### Changed

* Minor cleanups

## 2.9.0 (2024-08-01)

### Added

* Azure blob storage support.
* Introduced `pspdfkit.signingTrustConfigMaps` for ConfigMaps to mount to `/certificate-stores/`

### Changed

* [Document Engine 1.4.1](https://www.nutrient.io/changelog/document-engine/#1.4.1)

### Fixed

* Asset storage fallback.

## 2.8.0

### Added

* Support for OpenTelemetry traces, enabled by setting `pspdfkit.observability.opentelemetry.enabled` to `true`.
  * Unless the collector is placed as a sidecar and receives by grpc at port `4317`, other parameters are also necessary.
  * Please note: standard OpenTelemetry environment variables are used, and the following values are just convenience wrappers, therefore other configuration approaches (e.g. setting variables through mutations or post build patches) will also work.
  * Wrapped parameters (see `values.yaml` for more details):
    * `pspdfkit.observability.opentelemetry.otlpExporterEndpoint` (`OTEL_EXPORTER_OTLP_ENDPOINT`)
    * `pspdfkit.observability.opentelemetry.otlpExporterProtocol` (`OTEL_EXPORTER_OTLP_PROTOCOL`)
    * `pspdfkit.observability.opentelemetry.otelServiceName` (`OTEL_SERVICE_NAME`)
    * `pspdfkit.observability.opentelemetry.otelResourceAttributes` (`OTEL_RESOURCE_ATTRIBUTES`)
    * `pspdfkit.observability.opentelemetry.otelPropagators` (`OTEL_PROPAGATORS`)
* Dependent charts for [MinIO](https://min.io/) and [Redis](https://redis.io/).

### Changed

* [Document Engine 1.4.0](https://www.nutrient.io/changelog/document-engine/#1.4.0)
* Changed `pspdfkit.storage.enableMigrationJobs` to `pspdfkit.storage.databaseMigrationJob.enabled`.
* Renamed `.Values.pspdfkit.storage.redis.sentinels` to `.Values.pspdfkit.storage.redis.sentinel`.
* Slight refinement of trust information parameters: all files from `pspdfkit.trustConfigMaps` are now mounted to `/certificate-stores-custom/` to avoid confusion with `/certificate-stores/` which services for document signature validation certificates.

### Fixed

* Minor cleanups.

## 2.7.3

### Changed

* Moved changes from [README.md](/charts/document-engine/README.md) here.

### Fixed

* Corrected the comment in `values.yaml` (thanks to [Blaise Schaeffer](https://github.com/blaise2s)).

## 2.7.2

### Fixed

* Installing without license.

## 2.7.0

### Changed

* [Document Engine 1.3.0](https://www.nutrient.io/changelog/document-engine/#1.3.0)

## 2.6.2

### Added

* Added `deploymentAnnotations` (courtesy of [k11h.de](https://github.com/k11h-de)).
* Added `pspdfkit.storage.cleanupJob.podAnnotations`.

### Changed

* Updated StatsD Prometheus exporter image tag.

## 2.6.0

### Added

* Added ServiceMonitor for Prometheus Operator (setting `metrics.serviceMonitor.enabled` to `true` should work in most cases).
* Added PrometheusRule for Prometheus Operator.

## 2.4.0

### Added

* Added support for NetworkPolicy.

## 2.3.0

### Added

* Added a possibility to override backend in Ingress resources, in order to enable special configurations (e.g. AWS Load Balancer Controller).

## 2.2.0

### Added

* Added `pspdfkit.trustConfigMaps`, a map of ConfigMap references for trust certificates
* Added `pspdfkit.downloaderTrustFileName` for remote file downloader certificates file from `pspdfkit.trustConfigMaps`
* Added `pspdfkit.storage.postgres.tls.verify` (defaults to `true`) to enable PostgreSQL TLS certificate validation
* Added `pspdfkit.storage.postgres.tls.trustFileName` to specify the trust certificates file from `pspdfkit.trustConfigMaps` for PostgreSQL connection

## 2.1.0

### Changed

* Value `dashboardIngress` replaced by `extraIngresses` map to accommodate to more complex endpoint scenarios.

## 2.0.0

### Changed

* No more `createSecret` values, condition for creating secret by the chart are moved into definition of the corresponding external secret names.
* Storage parameters are now expected to fully reside in `Secret` resources
  * `pspdfkit.storage.postgres.auth`, `pspdfkit.storage.s3.auth`, `pspdfkit.storage.redis.auth` maps were all merged into the corresponding `pspdfkit.storage` higher level maps
  * Redis secret is now expected to contain (if existsis) all Redis parameters, not only the password
